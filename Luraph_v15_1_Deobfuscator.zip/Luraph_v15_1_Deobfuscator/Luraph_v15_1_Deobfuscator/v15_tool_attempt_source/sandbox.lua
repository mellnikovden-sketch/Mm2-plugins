-- Noir sandbox: runs an (obfuscated) script in a cage and records what it does.
-- usage: pandoc lua sandbox.lua <input.lua> <outdir> [limit in million instructions]
-- Captures every loadstring/load payload (the peeled layers), network calls, file writes, remotes and prints.
local input, outdir, limitM = arg[1], arg[2], tonumber(arg[3] or "80")
local real = { io = io, os = os, debug = debug, load = load, string = string, table = table, math = math, pcall = pcall }
local fh = assert(real.io.open(input, "rb")); local source = fh:read("a"); fh:close()

local out, saved, payloadN = {}, {}, 0
local function writeFile(name, text)
    local f = real.io.open(outdir .. "/" .. name, "wb"); if f then f:write(text); f:close() end
end
local function finish(reason)
    out[#out + 1] = "== END: " .. tostring(reason)
    writeFile("sandbox_log.txt", table.concat(out, "\n") .. "\n")
    real.os.exit(0, true)
end
local function show(v)
    local tv = type(v)
    if tv == "string" then return string.format("%q", #v > 240 and v:sub(1, 240) .. "...(" .. #v .. ")" or v) end
    return tostring(v)
end
local function log(kind, ...)
    local t = { kind }
    for i = 1, select("#", ...) do t[#t + 1] = tostring((select(i, ...))) end
    out[#out + 1] = table.concat(t, " ")
    if #out > 6000 then finish("LOG_LIMIT") end
end

-- ---------- recording proxies for every Roblox / executor global ----------
local names = setmetatable({}, { __mode = "k" })
local mt = {}
local function newProxy(name)
    local self = {}
    names[self] = name
    return setmetatable(self, mt)
end
mt.__index = function(t, k)
    local child = newProxy(names[t] .. (type(k) == "string" and ("." .. k) or ("[" .. tostring(k) .. "]")))
    rawset(t, k, child)
    return child
end
mt.__newindex = function(t, k, v) log("SET", names[t] .. "." .. tostring(k), "=", show(v)); rawset(t, k, v) end
mt.__call = function(t, ...)
    local args, name, shown, start = table.pack(...), names[t], {}, 1
    local first = args[1]
    if type(first) == "table" and names[first] and name:sub(1, #names[first] + 1) == names[first] .. "." then start = 2 end
    for i = start, args.n do shown[#shown + 1] = show(args[i]) end
    log("CALL", name .. "(" .. table.concat(shown, ", ") .. ")")
    if name:find("%.HttpGet") or name:find("%.HttpGetAsync") then return "" end
    return newProxy(name .. "()")
end
mt.__tostring = function(t) return names[t] end
mt.__concat = function(a, b) return tostring(a) .. tostring(b) end
mt.__len = function() return 0 end
for _, m in ipairs({ "__add", "__sub", "__mul", "__div", "__mod", "__pow", "__unm", "__idiv" }) do mt[m] = function() return 0 end end
mt.__lt = function() return false end
mt.__le = function() return false end
mt.__pairs = function(t) return function() return nil end, t, nil end

-- ---------- environment ----------
local env, genv = {}, {}
env._G, env._ENV = env, env
for _, k in ipairs({ "type", "tostring", "tonumber", "select", "next", "pairs", "ipairs", "rawget", "rawset", "rawequal",
    "rawlen", "setmetatable", "getmetatable", "error", "assert", "pcall", "xpcall", "utf8", "collectgarbage" }) do env[k] = _G[k] end
env.collectgarbage = function() return 0 end
env.unpack = table.unpack
local S = {}; for k, v in pairs(string) do S[k] = v end; S.dump = nil
function string.split(s, sep) local r = {}; for p in (s .. sep):gmatch("(.-)" .. (sep:gsub("%p", "%%%0"))) do r[#r + 1] = p end return r end
env.string = S
local T = {}; for k, v in pairs(table) do T[k] = v end
T.getn = function(t) return #t end
T.find = function(t, v, i) for n = i or 1, #t do if t[n] == v then return n end end end
T.clear = function(t) for k in pairs(t) do t[k] = nil end end
T.create = function(n, v) local r = {}; for i = 1, n do r[i] = v end return r end
env.table = T
local M = {}; for k, v in pairs(math) do M[k] = v end
M.clamp = function(x, a, b) return math.max(a, math.min(b, x)) end
M.round = function(x) return math.floor(x + 0.5) end
M.pow = function(a, b) return a ^ b end
M.sign = function(x) return x > 0 and 1 or (x < 0 and -1 or 0) end
env.math = M
env.os = { time = os.time, clock = os.clock, date = os.date }
env.debug = { traceback = function() return "" end, getinfo = function() return { currentline = 0, short_src = "", source = "", what = "Lua" } end }
env.bit32 = {
    band = function(a, b, ...) local r = (a & b) & 0xFFFFFFFF; for _, v in ipairs({ ... }) do r = r & v end return r end,
    bor = function(a, b, ...) local r = (a | b) & 0xFFFFFFFF; for _, v in ipairs({ ... }) do r = r | v end return r end,
    bxor = function(a, b, ...) local r = (a ~ b) & 0xFFFFFFFF; for _, v in ipairs({ ... }) do r = r ~ v end return r end,
    bnot = function(a) return (~a) & 0xFFFFFFFF end,
    lshift = function(a, n) return n >= 32 and 0 or ((a << n) & 0xFFFFFFFF) end,
    rshift = function(a, n) return n >= 32 and 0 or ((a & 0xFFFFFFFF) >> n) end,
    arshift = function(a, n) a = a & 0xFFFFFFFF; if a >= 0x80000000 then a = a - 0x100000000 end return (a >> n | (a < 0 and ~(0xFFFFFFFF >> n) or 0)) & 0xFFFFFFFF end,
    lrotate = function(a, n) n = n % 32; a = a & 0xFFFFFFFF; return ((a << n) | (a >> (32 - n))) & 0xFFFFFFFF end,
    rrotate = function(a, n) n = n % 32; a = a & 0xFFFFFFFF; return ((a >> n) | (a << (32 - n))) & 0xFFFFFFFF end,
    extract = function(a, f, w) return (a >> f) & ((1 << (w or 1)) - 1) end,
    btest = function(a, b) return (a & b) ~= 0 end,
}
env.bit = env.bit32

-- Luau-isms that stock Lua 5.4 cannot parse: compound assignment (best effort, one statement per line)
local function prep(src)
    src = src:gsub("\r", "")
    local lines = {}
    for line in (src .. "\n"):gmatch("(.-)\n") do
        local ind, lhs, rest = line:match("^(%s*)([%a_][%w_%.%[%]\"']*)%s*%.%.=%s*(.-)%s*$")
        if ind then line = ind .. lhs .. " = " .. lhs .. " .. (" .. rest .. ")"
        else
            local op
            ind, lhs, op, rest = line:match("^(%s*)([%a_][%w_%.%[%]\"']*)%s*([%+%-%*/%%%^])=%s*(.-)%s*$")
            if ind then line = ind .. lhs .. " = " .. lhs .. " " .. op .. " (" .. rest .. ")" end
        end
        lines[#lines + 1] = line
    end
    return table.concat(lines, "\n")
end

local function sandboxLoad(chunk, name, mode, e)
    if type(chunk) == "function" then
        local parts = {}
        while true do local p = chunk(); if not p or p == "" then break end; parts[#parts + 1] = p end
        chunk = table.concat(parts)
    end
    if type(chunk) ~= "string" then return nil, "bad chunk" end
    if #chunk > 40 and not saved[chunk] then
        saved[chunk] = true
        payloadN = payloadN + 1
        writeFile(("payload_%d.lua"):format(payloadN), chunk)
        log("LOADSTRING", "#" .. payloadN, #chunk .. " bytes", show(chunk:sub(1, 90)))
    end
    local fn, err = real.load(prep(chunk), "=payload", "t", type(e) == "table" and e or env)
    if not fn then log("LOAD_ERR", err); return nil, err end
    return fn
end
env.loadstring, env.load = sandboxLoad, sandboxLoad
env.getfenv = function() return env end
env.setfenv = function(f) return f end
env.newproxy = function() return newProxy("newproxy") end
env.shared = {}
env.print = function(...) local t = {}; for i = 1, select("#", ...) do t[#t + 1] = tostring((select(i, ...))) end log("PRINT", table.concat(t, " ")) end
env.warn = env.print

local instr, limit = 0, limitM * 10
local function hook()
    instr = instr + 1
    if instr > limit then finish("INSTRUCTION_LIMIT (" .. limitM .. "M)") end
    if collectgarbage("count") > 900000 then finish("MEMORY_LIMIT") end
end
local co = {}
for k, v in pairs(coroutine) do co[k] = v end
co.create = function(f) local c = coroutine.create(f); debug.sethook(c, hook, "", 100000); return c end
co.wrap = function(f) local c = co.create(f); return function(...) local r = table.pack(coroutine.resume(c, ...)); if not r[1] then error(r[2], 0) end return table.unpack(r, 2, r.n) end end
env.coroutine = co

local waits = 0
local function wait_() waits = waits + 1; if waits > 400 then finish("WAIT_LIMIT (script idles in a loop)") end return 0, 0 end
local function runNow(_, f, ...) end
local function spawnLike(f, ...)
    if type(f) == "function" then local ok, err = pcall(f, ...); if not ok then log("ERR", tostring(err)) end end
    return newProxy("thread")
end
env.task = { wait = wait_, spawn = spawnLike, defer = spawnLike, delay = function(_, f, ...) return spawnLike(f, ...) end, cancel = function() end }
env.wait, env.spawn, env.delay = wait_, spawnLike, function(_, f, ...) return spawnLike(f, ...) end
env.tick = os.clock
env.time = os.clock
env.typeof = function(v) if type(v) == "table" and names[v] then return "Instance" end return type(v) end

for _, g in ipairs({ "game", "workspace", "script", "Instance", "Enum", "Vector3", "Vector2", "CFrame", "Color3", "UDim2", "UDim",
    "BrickColor", "Ray", "Region3", "TweenInfo", "NumberSequence", "ColorSequence", "Random", "RaycastParams", "OverlapParams",
    "Drawing", "Players", "Lighting", "RunService", "HttpService" }) do env[g] = newProxy(g) end
env.getgenv = function() return genv end
env.getrenv = function() return env end
env.getrawmetatable = function(o) return getmetatable(o) or {} end
env.setreadonly = function() end
env.make_writeable = function() end
env.newcclosure = function(f) return f end
env.hookfunction = function(f, r) log("HOOK", "hookfunction"); return f end
env.hookmetamethod = function(o, m, f) log("HOOK", "hookmetamethod", tostring(m)); return function() end end
env.checkcaller = function() return true end
env.getgc = function() return {} end
env.getconnections = function() return {} end
env.identifyexecutor = function() return "Delta", "1.0" end
env.getexecutorname = env.identifyexecutor
env.isfile = function() return false end
env.isfolder = function() return false end
env.readfile = function(p) log("FILE", "readfile", show(p)); return "" end
env.writefile = function(p, c) log("FILE", "writefile", show(p), "(" .. #tostring(c) .. " bytes)"); end
env.appendfile = env.writefile
env.makefolder = function(p) log("FILE", "makefolder", show(p)) end
env.delfile = function(p) log("FILE", "delfile", show(p)) end
env.listfiles = function() return {} end
env.setclipboard = function(s) log("CLIPBOARD", show(s)) end
env.queue_on_teleport = function(s) log("QUEUE_ON_TELEPORT", show(s)) end
local function req(opt)
    log("HTTP", "request", type(opt) == "table" and (tostring(opt.Method or "GET") .. " " .. show(opt.Url or opt.url) .. (opt.Body and (" body=" .. show(opt.Body)) or "")) or show(opt))
    return { Body = "", StatusCode = 200, Success = true, Headers = {} }
end
env.request, env.http_request = req, req
env.syn = { request = req }
env.http = { request = req }
env.fluxus = { request = req }

debug.sethook(hook, "", 100000)
local fn, err = real.load(prep(source), "=input", "t", env)
if not fn then
    log("PARSE_ERR", err)
    finish("input does not parse as Lua 5.4 (Luau-only syntax?)")
end
local ok, e = pcall(fn)
if not ok then log("ERR", tostring(e)) end
finish(ok and "completed" or "stopped by error")
