#!/usr/bin/env python3
"""Noir deobfuscator: static layer peeling + sandbox run + report.
usage: python3 deobf.py <script> [outdir] [--limit N]    (N = million VM instructions for the sandbox, default 80)
"""
import re, sys, os, base64, subprocess, json, shutil, hashlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

HERE = os.path.dirname(os.path.abspath(__file__))

# ------------------------------------------------------------------ lua string literals
ESC = {"n": "\n", "t": "\t", "r": "\r", "a": "\a", "b": "\b", "f": "\f", "v": "\v", "\\": "\\", '"': '"', "'": "'", "\n": "\n"}

def read_string(src, i):
    """src[i] is a quote. returns (decoded bytes as str(latin-1), index after the closing quote) or None."""
    q = src[i]; j = i + 1; out = []
    n = len(src)
    while j < n:
        c = src[j]
        if c == q:
            return "".join(out), j + 1
        if c == "\n":
            return None
        if c == "\\":
            j += 1
            if j >= n: return None
            d = src[j]
            if d in ESC: out.append(ESC[d]); j += 1
            elif d == "x": out.append(chr(int(src[j + 1:j + 3], 16))); j += 3
            elif d == "z":
                j += 1
                while j < n and src[j] in " \t\r\n": j += 1
            elif d.isdigit():
                m = re.match(r"\d{1,3}", src[j:]); out.append(chr(int(m.group()) & 255)); j += len(m.group())
            elif d == "u" and src[j + 1] == "{":
                k = src.index("}", j); out.append(chr(int(src[j + 2:k], 16)).encode("utf-8").decode("latin-1")); j = k + 1
            else: out.append(d); j += 1
        else:
            out.append(c); j += 1
    return None

def read_long(src, i):
    m = re.match(r"\[(=*)\[", src[i:i + 40])
    if not m: return None
    close = "]" + m.group(1) + "]"
    k = src.find(close, i + len(m.group()))
    if k < 0: return None
    body = src[i + len(m.group()):k]
    if body.startswith("\n"): body = body[1:]
    return body, k + len(close)

def to_text(raw):
    """everything is processed as latin-1 text (one char = one byte) so the output is byte-exact."""
    return raw

def lua_quote(s):
    out = ['"']
    for ch in s:
        o = ord(ch)
        if ch == "\\": out.append("\\\\")
        elif ch == '"': out.append('\\"')
        elif ch == "\n": out.append("\\n")
        elif ch == "\r": out.append("\\r")
        elif ch == "\t": out.append("\\t")
        elif o < 32 or o == 127: out.append("\\%03d" % o)
        else: out.append(ch)
    out.append('"')
    return "".join(out)

# ------------------------------------------------------------------ detection
SIGNS = [
    ("Luraph", r"Luraph|luraph\.net|lura\.ph|lph[_ ]?(?:obf|jit)|LPH_"),
    ("IronBrew", r"IronBrew|IB2|ironbrew"),
    ("Prometheus", r"Prometheus|prometheus"),
    ("MoonSec", r"MoonSec|moonsec"),
    ("WeAreDevs", r"wearedevs|WeAreDevs"),
    ("Synapse Xen", r"Synapse Xen|Xenon"),
    ("PSU", r"PSU|psu\.dev"),
    ("Hercules", r"Hercules|herc\.uno"),
    ("NRX2 wrapper (base64 chunks)", r"_chunks\s*=\s*\{.*b64decode|NRX2"),
]

def detect(src):
    found = [n for n, p in SIGNS if re.search(p, src[:6000] + src[-2000:], re.S)]
    esc = len(re.findall(r"\\\d{1,3}|\\x[0-9a-fA-F]{2}", src)) / max(len(src), 1)
    if esc > 0.15: found.append("string-escape heavy (%.0f%% of chars)" % (esc * 100))
    if re.search(r"local \w+=\{\[?\d+\]?=", src[:3000]) and len(src) > 50000: found.append("VM-style dispatcher table (Luraph / IronBrew-like)")
    if len(re.findall(r"\b[Il1O0]{6,}\b", src)) > 50: found.append("IlIlIl-style identifiers")
    return found or ["no known signature"]

# ------------------------------------------------------------------ static peeling
def peel_once(src):
    # 1. base64 chunk-array wrapper (_chunks = { "...", ... } + b64decode + loadstring)
    if re.search(r"_chunks\s*=\s*\{", src) and "b64decode" in src:
        parts = re.findall(r'^\s*"([A-Za-z0-9+/=]+)",?\s*$', src, re.M)
        if parts:
            try: return to_text(base64.b64decode("".join(parts) + "==").decode("latin-1")), "base64 chunk wrapper"
            except Exception: pass
    # 2. loadstring / load with a literal string payload
    for m in re.finditer(r"\b(?:loadstring|load)\s*\(\s*", src):
        i = m.end()
        if i >= len(src): continue
        lit = read_string(src, i) if src[i] in "\"'" else (read_long(src, i) if src[i] == "[" else None)
        if not lit: continue
        body, k = lit
        rest = src[k:k + 20].lstrip()
        if rest.startswith(")"):
            text = to_text(body) if src[i] in "\"'" else body
            if len(text) > 30: return text, "loadstring(literal)"
    # 3. loadstring(<base64 literal decoder>("...")) style: a long base64 literal fed to any function inside loadstring
    for m in re.finditer(r"\b(?:loadstring|load)\s*\(\s*[\w\.:]+\s*\(\s*([\"'])([A-Za-z0-9+/=\s]{200,})\1", src):
        try:
            raw = base64.b64decode(re.sub(r"\s", "", m.group(2)) + "==")
            txt = to_text(raw.decode("latin-1"))
            if re.search(r"\b(local|function|end|return)\b", txt) and sum(c.isprintable() or c in "\n\t\r" for c in txt) / len(txt) > 0.95:
                return txt, "loadstring(base64 literal)"
        except Exception: pass
    return None, None

_TOK = re.compile(r"""
 (?P<ws>[ \t\r\n]+)
|(?P<lcom>--\[(?P<ce>=*)\[)
|(?P<com>--[^\n]*)
|(?P<lstr>\[(?P<se>=*)\[)
|(?P<str>"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')
|(?P<id>[A-Za-z_]\w*)
|(?P<num>0[xX][0-9a-fA-F]+|\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+)
|(?P<op>.)
""", re.X | re.S)

def tokenize_for_fold(src):
    """yield (kind, value, raw); whitespace runs are one ('op', ' ' or '\\n', run) token; every byte is kept."""
    i, n = 0, len(src)
    while i < n:
        m = _TOK.match(src, i); k = m.lastgroup; raw = m.group()
        if k == "ws":
            yield ("op", "\n" if "\n" in raw else " ", raw); i = m.end(); continue
        if k in ("lcom", "lstr"):
            eq = m.group("ce") if k == "lcom" else m.group("se")
            close = "]" + eq + "]"; j = src.find(close, m.end()); j = n if j < 0 else j + len(close)
            if k == "lcom": yield ("comment", "", src[i:j])
            else:
                body = src[m.end():j - len(close)]
                yield ("long", body[1:] if body.startswith("\n") else body, src[i:j])
            i = j; continue
        if k == "com": yield ("comment", "", raw); i = m.end(); continue
        if k == "str":
            r = read_string(src, i)
            if r: yield ("str", r[0], src[i:r[1]]); i = r[1]; continue
            yield ("op", raw[0], raw[0]); i += 1; continue
        if k == "id": yield ("id", raw, raw); i = m.end(); continue
        if k == "num": yield ("num", raw, raw); i = m.end(); continue
        yield ("op", raw, raw); i = m.end()

def normalize(src):
    """decode string escapes, fold literal concatenation and string.char(...), hex numbers -> decimal."""
    toks = list(tokenize_for_fold(src))
    out = []
    i = 0
    while i < len(toks):
        k, v, raw = toks[i]
        if k == "num" and re.fullmatch(r"0[xX][0-9a-fA-F]+", v):
            out.append(str(int(v, 16))); i += 1; continue
        if k == "id" and v == "char" and i >= 2 and toks[i - 1][2] == "." and toks[i - 2][2] == "string" and toks[i + 1][2] == "(":
            j = i + 2; nums = []; ok = True
            while j < len(toks):
                if toks[j][0] == "num" and re.fullmatch(r"\d+", toks[j][1]): nums.append(int(toks[j][1])); j += 1
                else: ok = False; break
                if toks[j][2] == ",": j += 1; continue
                break
            if ok and nums and j < len(toks) and toks[j][2] == ")" and all(0 <= x < 256 for x in nums):
                # drop the already-emitted "string" "." tokens
                while out and out[-1] in (".",): out.pop()
                if out and out[-1] == "string": out.pop()
                out.append(lua_quote(to_text("".join(chr(x) for x in nums)))); i = j + 1; continue
        if k == "str":
            out.append(lua_quote(to_text(v))); i += 1; continue
        out.append(raw); i += 1
    text = "".join(out)
    # "a" .. "b"  ->  "ab"   (only plain literals, repeated until stable)
    pat = re.compile(r'("(?:[^"\\\n]|\\.)*")\s*\.\.\s*("(?:[^"\\\n]|\\.)*")')
    for _ in range(50):
        new = pat.sub(lambda m: m.group(1)[:-1] + m.group(2)[1:], text)
        if new == text: break
        text = new
    return text

EXPR_PREV = {"=", "(", ",", "return", "{", "or", "and", "not", "..", "+", "-", "*", "/", "%", "^", "==", "~=", "<", ">", "<=", ">=", "[", "#", "+=", "-=", "*=", "/=", "..="}
KEYWORDS = {"local", "function", "return", "if", "then", "else", "elseif", "do", "repeat", "until", "in", "and", "or", "not", "for", "while", "break", "goto", "end", "true", "false", "nil"}
CONTINUES = {"and", "or", "not", "in", "then", "do", "else", "elseif", "end", "until"}
def beautify(src):
    """re-indent: one statement per line, 4 spaces per block; minified statements are split; Luau if-expressions stay inline."""
    from luau import toks as merged
    toks = [t for t in merged(src) if not (t[0] == "op" and t[1] in (" ", "\n", "\t", "\r"))]
    out, line, stack = [], [], []
    expr_if = pending_do = 0
    prev = ""; prev_kind = ""; prev_val = ""
    level = 0
    def flush(_lv=None):
        nonlocal line
        s = "".join(line).strip()
        if s: out.append("    " * min(max(level, 0), 40) + s)
        line = []
    def operand_end():
        if prev_kind in ("num", "str", "long"): return True
        if prev_kind == "id": return prev_val not in KEYWORDS or prev_val in ("end", "true", "false", "nil")
        return prev in (")", "]", "}")
    for k, v, raw in toks:
        if k == "comment":
            flush(len(stack)); out.append("    " * min(len(stack), 40) + raw.strip()); prev = prev_val = prev_kind = ""; continue
        word = v if k == "id" else ""
        is_expr_if = word == "if" and prev in EXPR_PREV
        # a new statement starts where an operand is followed by an identifier / statement keyword
        boundary = bool(line) and operand_end() and k == "id" and word not in CONTINUES and not is_expr_if
        if boundary:
            expr_if = 0
            flush(len(stack) if word != "end" else len(stack) - 1)
        if is_expr_if: expr_if += 1
        if word in ("end", "until"):
            if not boundary: flush(len(stack))
            if stack: stack.pop()
            line_level_fix = None
        elif word in ("else", "elseif") and expr_if == 0:
            flush(len(stack) - 1)
        glue = ""
        if line:
            if raw in (",", ";", ")", "]", "}", ".", ":", "::", "?") or prev in ("(", "[", "{", ".", ":", "#", "::"): glue = ""
            elif raw in ("(", "[") and (prev_kind in ("id", "str", "long", "num") and prev_val not in KEYWORDS or prev in (")", "]", "}")): glue = ""
            else: glue = " "
        if not line:
            level = len(stack) - (1 if word in ("else", "elseif") and expr_if == 0 and stack else 0)
        line.append(glue + raw)
        skip_flush = word in ("then", "else") and expr_if > 0
        if word == "function" or (word == "if" and not is_expr_if) or word == "repeat": stack.append(word)
        elif word in ("for", "while"): stack.append(word); pending_do += 1
        elif word == "do":
            if pending_do: pending_do -= 1
            else: stack.append(word)
        if word == "else" and expr_if > 0: expr_if -= 1
        if (word in ("then", "do", "repeat", "else") and not skip_flush) or raw == ";":
            flush(len(stack) - (1 if word in ("then", "do", "repeat") else 0) if word != "else" else len(stack))
        prev, prev_kind, prev_val = raw, k, v
    flush(len(stack))
    return "\n".join(out) + "\n"

# ------------------------------------------------------------------ indicators
IOC = [
    ("url", r"https?://[^\s\"'\)\]\\<>]+"),
    ("discord webhook", r"https?://(?:ptb\.|canary\.)?discord(?:app)?\.com/api/webhooks/[^\s\"'\)\\]+"),
    ("roblox cookie", r"\.ROBLOSECURITY|_\|WARNING:-DO-NOT-SHARE"),
    ("asset id", r"rbxassetid://\d+"),
    ("clipboard", r"setclipboard|toclipboard"),
    ("file write", r"writefile|appendfile"),
    ("remote/teleport", r"TeleportService|queue_on_teleport|\.Kick\b|:Kick\("),
    ("hwid / user info", r"gethwid|HWID|GetHwid|RbxAnalyticsService|ClientId"),
]
def indicators(text):
    res = {}
    for name, p in IOC:
        found = sorted(set(re.findall(p, text)))
        if found: res[name] = found[:25]
    return res

NOISE = re.compile(r"^(Color3|Vector[23]|UDim2?|CFrame|Enum|TweenInfo|BrickColor|NumberSequence|ColorSequence|Instance\.new|Random|Ray|Region3|Rect|Font)\b")
SUSPICIOUS = re.compile(r"Kick|Teleport|FireServer|InvokeServer|setclipboard|HttpGet|HttpPost|PostAsync|RequestAsync|GetAsync|MarketplaceService|PromptPurchase|PromptProductPurchase|PromptGamePassPurchase|queue_on_teleport|\.Shutdown|ROBLOSECURITY|GetUserId|UserId|AccountAge|HttpService|WebSocket|SendMessage|saveinstance|decompile|getscriptbytecode", re.I)
def summarize(log):
    lines = log.splitlines()
    calls = {}; sets = 0; groups = {"HTTP": [], "LOADSTRING": [], "FILE": [], "CLIPBOARD": [], "QUEUE_ON_TELEPORT": [], "HOOK": [], "ERR": [], "PRINT": []}
    services = []; suspicious = []
    for l in lines:
        kind = l.split(" ", 1)[0]
        if kind == "CALL":
            body = l[5:]
            name = body.split("(", 1)[0]
            m = re.match(r'game\.GetService\("(\w+)"\)', body)
            if m and m.group(1) not in services: services.append(m.group(1))
            calls[name] = calls.get(name, 0) + 1
            if SUSPICIOUS.search(body) and not NOISE.match(body) and body not in suspicious and len(suspicious) < 60: suspicious.append(body[:220])
        elif kind == "SET": sets += 1
        elif kind in groups and len(groups[kind]) < 60: groups[kind].append(l[:230])
    out = ["## sandbox summary", f"{len(lines)} log lines, {sum(calls.values())} recorded calls, {sets} property sets (full log: sandbox/sandbox_log.txt)"]
    end = next((l for l in reversed(lines) if l.startswith("== END")), "")
    if end: out.append(end)
    for title, key in (("network requests", "HTTP"), ("loadstring payloads", "LOADSTRING"), ("file access", "FILE"), ("clipboard", "CLIPBOARD"), ("queue_on_teleport", "QUEUE_ON_TELEPORT"), ("hooks", "HOOK"), ("errors", "ERR")):
        if groups[key]:
            out.append(f"### {title} ({len(groups[key])})"); out += ["  " + x for x in groups[key][:25]]
    if suspicious:
        out.append(f"### interesting calls ({len(suspicious)})"); out += ["  " + x for x in suspicious[:30]]
    if services: out.append("### services touched: " + ", ".join(services[:40]))
    top = sorted(((c, n) for n, c in calls.items() if not NOISE.match(n)), reverse=True)[:25]
    if top:
        out.append("### most frequent calls"); out += [f"  {c:5d}  {n}" for c, n in top]
    if groups["PRINT"]:
        out.append("### prints"); out += ["  " + x for x in groups["PRINT"][:15]]
    return out

def is_luraph(src):
    return bool(re.search(r"protected using Luraph Obfuscator|lura\.ph|LPH_", src[:4000] + src[-1000:]))

def run_luraph(path, outdir, timeout):
    """Luraph v14/v15 devirtualizer (Aditya-lua/Deobfuscator-Luraph-V15, MIT): runs the script in an offline Roblox
    emulator, decrypts constants live and lifts the VM bytecode back to Luau source. Needs node 18+ and python 3.10+."""
    tool = os.path.join(HERE, "luraph")
    if not os.path.exists(os.path.join(tool, "deob.js")):
        return None, "luraph tool folder missing (put the project into ./luraph)"
    result = os.path.join(outdir, "luraph_result.lua")
    try:
        p = subprocess.run(["node", "deob.js", os.path.abspath(path), "-o", os.path.abspath(result)], cwd=tool,
                           capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return None, f"luraph devirtualizer timeout after {timeout}s (large scripts take 1-12 minutes: run it in the background)"
    log = (p.stdout or "") + (p.stderr or "")
    open(os.path.join(outdir, "luraph_log.txt"), "w", encoding="latin-1").write(log)
    if os.path.exists(result) and os.path.getsize(result) > 0:
        return result, log
    return None, log[-1500:]

def run_sandbox(path, outdir, limit):
    os.makedirs(outdir, exist_ok=True)
    cmd = ["timeout", "120", "bash", "-c", f"ulimit -v 3000000; pandoc lua '{os.path.join(HERE, 'sandbox.lua')}' '{path}' '{outdir}' {limit}"]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=130)
    except subprocess.TimeoutExpired:
        return "sandbox timeout", []
    log = os.path.join(outdir, "sandbox_log.txt")
    text = open(log, encoding="latin-1").read() if os.path.exists(log) else (p.stderr or "no log")[:2000]
    payloads = sorted(f for f in os.listdir(outdir) if f.startswith("payload_"))
    return text, payloads

def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    limit = 80
    if "--limit" in sys.argv: limit = int(sys.argv[sys.argv.index("--limit") + 1]); args = [a for a in args if a != str(limit)]
    if not args: print(__doc__); return
    src_path = args[0]
    outdir = args[1] if len(args) > 1 else os.path.splitext(src_path)[0] + "_deobf"
    os.makedirs(outdir, exist_ok=True)
    src = open(src_path, encoding="latin-1").read()
    report = ["# Deobfuscation report", f"input: {os.path.basename(src_path)}  ({len(src)} bytes, {src.count(chr(10)) + 1} lines)",
              "signature: " + "; ".join(detect(src)), ""]
    if is_luraph(src) and "--no-luraph" not in sys.argv:
        tmo = int(sys.argv[sys.argv.index("--luraph-timeout") + 1]) if "--luraph-timeout" in sys.argv else 280
        res, info = run_luraph(src_path, outdir, tmo)
        if res:
            lua = open(res, encoding="latin-1").read()
            report.append(f"LURAPH devirtualized: luraph_result.lua ({len(lua)} bytes, {lua.count(chr(10)) + 1} lines)")
            report.append("")
            report.append("## indicators in the devirtualized source")
            ioc = indicators(lua)
            if not ioc: report.append("none found")
            for k, v in ioc.items():
                report.append(f"- {k}:")
                for x in v: report.append(f"    {x}")
            open(os.path.join(outdir, "report.md"), "w", encoding="latin-1").write("\n".join(report) + "\n")
            print("\n".join(report)); print("\nfiles in", outdir); return
        report.append("LURAPH devirtualizer did not finish: " + str(info).strip().splitlines()[-1][:300] if str(info).strip() else "LURAPH devirtualizer did not finish")
        report.append("(falling back to the generic static + sandbox pipeline)")
    layers = [("input", src)]
    cur = src
    for n in range(1, 9):
        nxt, how = peel_once(cur)
        if not nxt or nxt == cur: break
        layers.append((how, nxt)); cur = nxt
        report.append(f"static layer {n}: {how} -> {len(nxt)} bytes")
    clean = beautify(normalize(cur))
    open(os.path.join(outdir, "static_result.lua"), "w", encoding="latin-1").write(clean)
    report.append(f"static result: static_result.lua ({len(clean)} bytes, strings decoded, literals folded, re-indented)")
    # sandbox on the deepest static layer
    work = os.path.join(outdir, "_input.lua")
    try:
        from luau import luau_to_lua
        runnable = luau_to_lua(cur)
    except Exception as e:
        runnable = cur; report.append(f"(luau downgrade failed: {e}; running the source as is)")
    open(work, "w", encoding="latin-1").write(runnable)
    sbdir = os.path.join(outdir, "sandbox")
    shutil.rmtree(sbdir, ignore_errors=True)
    log, payloads = run_sandbox(work, sbdir, limit)
    report.append("")
    report.append(f"sandbox: {len(payloads)} payload(s) captured via loadstring/load -> sandbox/")
    best = None
    for p in payloads:
        txt = open(os.path.join(sbdir, p), encoding="latin-1").read()
        cl = beautify(normalize(txt))
        open(os.path.join(sbdir, p.replace(".lua", "_clean.lua")), "w", encoding="latin-1").write(cl)
        report.append(f"  {p}: {len(txt)} bytes")
        best = (p, cl)
    m = re.search(r"PARSE_ERR input:(\d+): (.*)", log)
    if m:
        ln = int(m.group(1)); rl = open(work, encoding="latin-1").read().split("\n")
        report.append("")
        report.append(f"sandbox could not parse the script: line {ln}: {m.group(2)}  (the code may be invalid / decompiler output, or Luau syntax the converter does not cover)")
        for x in range(max(0, ln - 3), min(len(rl), ln + 2)): report.append(f"  {x + 1}| {rl[x][:160]}")
    report.append("")
    report.append("## indicators (static + sandbox log)")
    allt = clean + "\n" + log + "\n" + "\n".join(open(os.path.join(sbdir, p), encoding='latin-1').read() for p in payloads)
    ioc = indicators(allt)
    if not ioc: report.append("none found")
    for k, v in ioc.items():
        report.append(f"- {k}:")
        for x in v: report.append(f"    {x}")
    report.append("")
    report += summarize(log)
    open(os.path.join(outdir, "report.md"), "w", encoding="latin-1").write("\n".join(report) + "\n")
    print("\n".join(report[:60]))
    print("\nfiles in", outdir)

if __name__ == "__main__":
    main()
