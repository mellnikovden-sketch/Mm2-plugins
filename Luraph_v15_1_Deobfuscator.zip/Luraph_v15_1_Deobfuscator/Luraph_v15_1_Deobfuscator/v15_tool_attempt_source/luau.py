"""Luau -> Lua 5.4 downgrade for the sandbox: continue, if-expressions, compound assignment, type annotations."""
import re
from deobf import tokenize_for_fold

SPACE = (" ", "\t", "\r", "\n")
EXPR_START_PREV = {"=", "(", ",", "return", "{", "or", "and", "not", "..", "+", "-", "*", "/", "%", "^", "==", "~=", "<", ">", "<=", ">=", "[", "#"}
STOP_KW = {"end", "then", "do", "else", "elseif", "until", "local", "return", "for", "while", "repeat", "break", "function_stmt"}

OPS = {"...", "..=", "//=", "==", "~=", "<=", ">=", "..", "+=", "-=", "*=", "/=", "%=", "^=", "//", "::", "->"}
def toks(src):
    """[(kind, value, raw)] with adjacent single-character operators merged (==, ~=, .., ..., +=, ::, ...)."""
    raw = list(tokenize_for_fold(src))
    out = []; i = 0; n = len(raw)
    while i < n:
        k, v, r = raw[i]
        if k == "op" and v not in SPACE:
            chars = [r]; j = i + 1
            while j < n and len(chars) < 3 and raw[j][0] == "op" and raw[j][1] not in SPACE and len(raw[j][2]) == 1:
                chars.append(raw[j][2]); j += 1
            for length in (3, 2):
                if len(chars) >= length and "".join(chars[:length]) in OPS:
                    cand = "".join(chars[:length]); out.append(("op", cand, cand)); i += length; break
            else:
                out.append((k, v, r)); i += 1
            continue
        out.append((k, v, r)); i += 1
    return out

def sig_prev(t, i):
    j = i - 1
    while j >= 0 and (t[j][0] == "comment" or (t[j][0] == "op" and t[j][1] in SPACE)): j -= 1
    return t[j] if j >= 0 else None

def sig_next(t, i):
    j = i + 1
    while j < len(t) and (t[j][0] == "comment" or (t[j][0] == "op" and t[j][1] in SPACE)): j += 1
    return j

def is_if_expr(t, i):
    p = sig_prev(t, i)
    if p is None: return False
    return p[1] in EXPR_START_PREV and p[0] in ("op", "id") and not (p[0] == "id" and p[1] not in ("return", "or", "and", "not"))

def scan_expr(t, i, stop_vals):
    """index of the first depth-0 token that ends the expression starting at i."""
    depth = 0; operand = False; fn_depth = 0
    while i < len(t):
        k, v, r = t[i]
        if k == "comment" or (k == "op" and v in SPACE): i += 1; continue
        if k == "op" and v in "([{": depth += 1; operand = False; i += 1; continue
        if k == "op" and v in ")]}":
            if depth == 0: return i
            depth -= 1; operand = True; i += 1; continue
        if depth == 0 and k == "op" and v in (",", ";"): return i
        if k == "id" and v == "function": fn_depth += 1
        if k == "id" and v == "end" and fn_depth > 0: fn_depth -= 1; operand = True; i += 1; continue
        if fn_depth == 0 and depth == 0 and k == "id" and v in ("end", "then", "do", "else", "elseif", "until", "local", "return", "for", "while", "repeat", "break"): return i
        if depth == 0 and fn_depth == 0 and k == "id" and v == "if":
            p = sig_prev(t, i)
            if p is None or not (p[1] in EXPR_START_PREV): return i  # a new statement
            # nested if-expression: skip it whole
            i = skip_ifexpr(t, i); operand = True; continue
        if depth == 0 and fn_depth == 0 and k in ("id", "num", "str", "long") and operand and v not in ("and", "or", "not"):
            return i
        if k in ("id", "num", "str", "long"):
            operand = not (k == "id" and v in ("and", "or", "not"))
        elif k == "op" and v in (".", ":"): operand = False
        elif k == "op" and v not in ")]}": operand = False
        i += 1
    return i

def skip_ifexpr(t, i):
    _, j = parse_ifexpr(t, i)
    return j

def parse_ifexpr(t, i):
    """t[i] is `if` in expression position -> (lua text, index after the expression)."""
    cond_end = scan_expr(t, sig_next(t, i), {"then"})
    clauses = []
    j = cond_end
    cond = conv(t[sig_next(t, i):cond_end])
    assert t[j][1] == "then", "then expected"
    j = sig_next(t, j - 1) if False else j + 1
    while True:
        val_end = scan_expr(t, j, {"else", "elseif"})
        val = conv(t[j:val_end])
        clauses.append((cond, val))
        k = val_end
        while k < len(t) and (t[k][0] == "comment" or (t[k][0] == "op" and t[k][1] in SPACE)): k += 1
        if k < len(t) and t[k][1] == "elseif":
            c_end = scan_expr(t, k + 1, {"then"}); cond = conv(t[k + 1:c_end]); j = c_end + 1; continue
        if k < len(t) and t[k][1] == "else":
            e_end = scan_expr(t, k + 1, set()); other = conv(t[k + 1:e_end]); j = e_end; break
        other = "nil"; j = val_end; break
    body = " ".join(f"{'if' if n == 0 else 'elseif'} {c} then return {v}" for n, (c, v) in enumerate(clauses)) + f" else return {other} end"
    seg = "".join(x[2] for x in t[i:j])
    va = "..." in body  # a vararg inside the wrapper must be passed through
    head, call = ("(function(...) ", "(...)") if va else ("(function() ", "()")
    return head + body + " end)" + call + seg[len(seg.rstrip()):], j

def conv(tokens):
    """convert a token slice that contains no statements."""
    out = []; i = 0
    while i < len(tokens):
        k, v, r = tokens[i]
        if k == "id" and v == "if" and is_if_expr(tokens, i):
            text, j = parse_ifexpr(tokens, i); out.append(text); i = j; continue
        out.append(r); i += 1
    return "".join(out).strip()

def strip_types(t):
    """remove `: Type` after parameters / locals, `:: Type` casts, return types and `type X = ...` statements."""
    out = []; i = 0; n = len(t)
    def skip_type(j):
        # consume a type expression starting at j (after the ':')
        depth = 0; seen = False
        while j < n:
            k, v, r = t[j]
            if k in ("comment",) or (k == "op" and v in SPACE):
                if depth == 0 and seen and k == "op" and v == "\n": return j
                j += 1; continue
            if k == "op" and v in "<({[": depth += 1; j += 1; seen = True; continue
            if k == "op" and v in ">)}]":
                if depth == 0: return j
                depth -= 1; j += 1; continue
            if depth > 0: j += 1; continue
            if k == "id" and not seen: seen = True; j += 1; continue
            if k == "op" and v in (".", "|", "&", "?"): j += 1; seen = False if v in ("|", "&", ".") else seen; continue
            if k == "id" and not seen: j += 1; seen = True; continue
            return j
        return j
    in_params = 0; param_depth = 0
    while i < n:
        k, v, r = t[i]
        if k == "id" and v == "type" and (sig_prev(t, i) is None or sig_prev(t, i)[1] in ("\n", ";") or (sig_prev(t, i)[0] == "id" and sig_prev(t, i)[1] == "export")):
            nx = sig_next(t, i)
            if nx < n and t[nx][0] == "id" and t[nx][1] not in ("=",):
                # skip statement `type Name<...> = ...`
                j = nx; depth = 0
                while j < n:
                    kk, vv, rr = t[j]
                    if kk == "op" and vv in "{([<": depth += 1
                    elif kk == "op" and vv in "})]>": depth -= 1
                    if vv == "\n" and depth <= 0 and any(t[x][1] == "=" for x in range(nx, j)): break
                    j += 1
                i = j; continue
        if k == "op" and v == "::":
            j = skip_type(i + 1); i = j; continue
        if k == "id" and v == "function":
            out.append(r); i += 1; in_params = 1; continue
        if in_params == 1 and k == "op" and v == "(":
            in_params = 2; param_depth = 1; out.append(r); i += 1; continue
        if in_params == 2:
            if k == "op" and v in "([{": param_depth += 1
            if k == "op" and v in ")]}":
                param_depth -= 1
                if param_depth == 0:
                    out.append(r); i += 1; in_params = 0
                    nx = sig_next(t, i - 1)
                    if nx < n and t[nx][1] == ":" :
                        i = skip_type(nx + 1)
                    continue
            if k == "op" and v == ":" and param_depth == 1:
                i = skip_type(i + 1); continue
        if k == "id" and v == "local":
            out.append(r); i += 1
            # local a, b: T = ...
            while i < n:
                kk, vv, rr = t[i]
                if kk == "op" and vv == ":":
                    i = skip_type(i + 1); continue
                if kk == "op" and vv in ("=", "\n", ";"): break
                if kk == "id" and vv == "function": break
                out.append(rr); i += 1
            continue
        out.append(r); i += 1
    return out

VALID_ESC = set("abfnrtv\\\"'\nxzu0123456789")
def fix_escapes(src):
    """Luau / Lua 5.1 accept unknown escapes like "\\]"; Lua 5.4 does not: drop the backslash."""
    out = []
    for k, v, r in tokenize_for_fold(src):
        if k == "str" and "\\" in r:
            fixed = []; i = 0
            while i < len(r):
                c = r[i]
                if c == "\\" and i + 1 < len(r):
                    d = r[i + 1]
                    if d in VALID_ESC: fixed.append(c + d)
                    else: fixed.append(d)
                    i += 2; continue
                fixed.append(c); i += 1
            r = "".join(fixed)
        out.append(r)
    return "".join(out)

def luau_to_lua(src):
    src = fix_escapes(src)
    t = toks("".join(strip_types(toks(src))))
    # 1. if-expressions
    out = []; i = 0
    while i < len(t):
        k, v, r = t[i]
        if k == "id" and v == "if" and is_if_expr(t, i):
            try:
                text, j = parse_ifexpr(t, i); out.append(text); i = j; continue
            except Exception:
                pass
        out.append(t[i]); i += 1
    t2 = []
    for item in out:
        t2.append(item if isinstance(item, tuple) else ("raw", item, item))
    # 2. compound assignment  a.b += x  ->  a.b = a.b + (x)   (statement level, ends at newline / ; / next statement keyword)
    res = []; i = 0
    ops = {"+=": "+", "-=": "-", "*=": "*", "/=": "/", "%=": "%", "^=": "^", "..=": "..", "//=": "//"}
    while i < len(t2):
        k, v, r = t2[i]
        if k == "op" and v in ops:
            # target = back to the statement start
            j = len(res) - 1
            while j >= 0 and res[j] in (" ", "\t"): j -= 1
            target = []
            depth = 0
            while j >= 0:
                piece = res[j]
                if piece in (")", "]"): depth += 1
                elif piece in ("(", "["): depth -= 1
                if depth == 0 and (piece == ";" or (piece.strip() == "" and "\n" in piece)): break
                if depth == 0 and piece.strip() in ("then", "do", "else", "end", "repeat") : break
                target.append(piece); j -= 1
            target.reverse(); tgt = "".join(target).strip()
            del res[j + 1:]
            res.append(" ")
            # rhs: until newline at depth 0
            m = i + 1; depth = 0; rhs = []
            while m < len(t2):
                kk, vv, rr = t2[m]
                if kk == "op" and vv in "([{": depth += 1
                if kk == "op" and vv in ")]}": depth -= 1
                if depth <= 0 and ((kk == "op" and vv in ("\n", ";")) or (kk == "id" and vv in ("end", "else", "elseif", "until") and depth == 0)): break
                rhs.append(rr); m += 1
            rhs_text = "".join(rhs)
            res.append(f"{tgt} = {tgt} {ops[v]} ({rhs_text.strip()})" + (rhs_text[len(rhs_text.rstrip()):] or " "))
            i = m; continue
        res.append(r); i += 1
    src2 = "".join(res)
    # 3. continue -> goto (label right before the loop's `end`)
    t3 = toks(src2)
    stack = []; loops = {}; counter = 0; conts = []
    pending_do = 0
    for idx, (k, v, r) in enumerate(t3):
        if k != "id": continue
        if v in ("function", "if", "repeat"): stack.append(("blk", idx))
        elif v in ("for", "while"): counter += 1; stack.append(("loop", idx, counter)); pending_do += 1
        elif v == "do":
            if pending_do: pending_do -= 1
            else: stack.append(("blk", idx))
        elif v in ("end", "until"):
            if stack:
                top = stack.pop()
                if top[0] == "loop": loops[idx] = top[2]
        elif v == "continue":
            p = sig_prev(t3, idx)
            nx = sig_next(t3, idx)
            if p and p[1] in (".", ":"): continue
            loop = next((s for s in reversed(stack) if s[0] == "loop"), None)
            if loop: conts.append((idx, loop[2]))
    cmap = dict(conts); lmap = loops
    res = []
    for idx, (k, v, r) in enumerate(t3):
        if idx in cmap: res.append(f"goto __cont{cmap[idx]}"); continue
        if idx in lmap and any(c[1] == lmap[idx] for c in conts): res.append(f"::__cont{lmap[idx]}:: ")
        res.append(r)
    return "".join(res)
